// Copyright (C) 2021 John Nesky, distributed under the MIT license.

export interface Prompt {
	container: HTMLElement;
	cleanUp: ()=>void;
}
